// index.js
Page({
  data:{
    region:['安徽省','芜湖市','镜湖区'],
    now:{
    tmp:0,
    cond_txt:'未知',
    cond_code:'999',
    hum:0,
    pres:0,
    vis:0,
    wind_dir:0,
    wind_spd:0,
    wind_sc:0
    }
  },
  getWeather:function(){
    var that = this;
    wx.request({
      url:'https://free-api.heweather.com/s6/weather/now',
      data:{
        location:that.data.region[1],
        key:'f0671b6589ff43019e72970d334ea93e'
      },
      success:function(res){
        console.log(res.data);
        that.setData({now:res.data.HeWeather6[0].now});
      }
    })
  },

  regionChange:function(e){
    this.setData({region:e.detail.value});
    this.getWeather();
  },

  onLoad:function(options){
    this.getWeather();
  }
})
